#ifndef UNTITLED_FUNCTIONS_H
#define UNTITLED_FUNCTIONS_H


#include <stdio.h>
#define BUFFER_INITIAL_SIZE 1024
#define BUFFER_EXTENDS 100
#define ERROR_NO_MEMORY -1
//lista de caracteres legales o permitidos por el enunciado
static const char LEGAL_CHARS[] = "QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm1234567890-_";


static const char OPTIONS[] = "Vhio";

//Funcion para validar la ruta de los archivos de entrada y salida
int validarRutaArchivo(FILE* file,char *argv);

//Funcion de prueba para validar los ingresos por consola, luego sera la funcion palindrome de MIPS
int funcionMips(int ifd, int ofd, int buffer_size_read, int buffer_size_write);

//Valida que el tamaño de los buffer sea mayor o igual a 1
int validarBuffer(char * argv);

//Comportamiento si el programa se ejecuta sin argumentos leee y escribe entrada y salida estandar
int no_arguments();

//COmportamiento con un argumento ya sea entrada o salida
int one_argument(int argc, char *argv[]);

// Comportamiento con dos argumentos entrada y salida en cualquier orden
int two_arguments(int argc, char *argv[]);

//Comportamiento con tres argumentos, combinando entrada, salida, buffer de escritura y buffer de lectura
int three_arguments(int argc, char* argv[]);

//Comportamiento con cuatro argumentos, combinando entrada, salida, buffer de escritura y buffer de lectura
int four_arguments(int argc, char* argv[]);

//Muestra la descipcion de la version
int versionDisplay();

//Muestra el menu de ayuda
int helpDisplay();

//Comportamiento para mostrar ayuda o opciones
int version_option(int argc, char*argv[]);

extern void palindromo(int,int,int,int);


#endif //UNTITLED_FUNCTIONS_H
