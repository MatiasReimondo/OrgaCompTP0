#include "functions.h"
#include <ctype.h>
#include <string.h>
#include <getopt.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>


int validarRutaArchivo(FILE* file,char* argv){
    
    if(file == NULL){
    printf("El archivo %s no se encuentra en la ruta especificada \n",argv);
    return 0;
    }
    else{
    return 1;
    }
}

int funcionMips(int ifd, int ofd, int buffer_size_read, int buffer_size_write){

    palindromo(ifd,buffer_size_read,ofd,buffer_size_write);
    printf("ifd: %d || ofd: %d || bzr: %d || bzw: %d\n",ifd,ofd,buffer_size_read,buffer_size_write);
    return 0;
}

int validarBuffer(char * argv){
    int buffer = atoi(argv); 
     
    if(buffer < 1){
    printf("Tamaño del buffer incorrecto, el valor debe ser mayor a cero \n");
    return 0;
    }
    else{
    return 1;
    }
}


int no_arguments(){
    
    int exe_code = 0;

    int ifd = fileno(stdin);
    int ofd = fileno(stdout);

    int buffer_size_read = 1;
    int buffer_size_write = 1;

    //Llamamos a la funcion de MIPS.
    exe_code = funcionMips(ifd,ofd,buffer_size_read,buffer_size_write);
    return exe_code;
}

int one_argument(int argc, char *argv[]){
    
    int exe_code = 0;
    //File Pointers
    FILE *fw;
    FILE *fr;
    //File descriptors
    int ifd;
    int ofd;
    //buffer sizes
    int buffer_size_read;
    int buffer_size_write;

    if (strcmp(argv[1],"-i") == 0){
        fr = fopen(argv[2],"r");
        if(validarRutaArchivo(fr,argv[2])){
        fw = stdout;
        ifd = fileno(fr);
        ofd = fileno(fw);
        buffer_size_read = 1;
        buffer_size_write = 1;
        exe_code = funcionMips(ifd,ofd,buffer_size_read,buffer_size_write);
        fclose(fr);
        }
    }
    else if (strcmp(argv[1],"-o") == 0){
            
        fw = fopen(argv[2],"w");
        fr = stdin;
        ifd = fileno(fr);
        ofd = fileno(fw);
        buffer_size_read = 1;
        buffer_size_write = 1;
        exe_code = funcionMips(ifd,ofd,buffer_size_read,buffer_size_write);
        fclose(fw);
    }
    else if (strcmp(argv[1],"-I") == 0 && validarBuffer(argv[2])){
        fr = stdin;
        fw = stdout;
        ifd = fileno(fr);
        ofd = fileno(fw);
        buffer_size_read = atoi(argv[2]);
        buffer_size_write = 1;
        exe_code = funcionMips(ifd,ofd,buffer_size_read,buffer_size_write);
    }
    else if (strcmp(argv[1],"-O") == 0 && validarBuffer(argv[2])){
        fr = stdin;
        fw = stdout;
        ifd = fileno(fr);
        ofd = fileno(fw);
        buffer_size_read = 1;
        buffer_size_write = atoi(argv[2]);
        exe_code = funcionMips(ifd,ofd,buffer_size_read,buffer_size_write);
    }
    else if (strcmp(argv[1],"-V") == 0){
        versionDisplay();
    }
    else if (strcmp(argv[1],"-h") == 0){
        helpDisplay();
    }
    else {
    printf("Ingreso de comandos incorrectos \n");
    }

   return exe_code;
}

int two_arguments(int argc, char *argv[]){

    int exe_code = 0;
    //File pointers
    FILE *fr;
    FILE *fw;
    
    //File descriptors
    int ifd;
    int ofd;

    //Buffer sizes
    int buffer_size_read;
    int buffer_size_write;

    if ((strcmp (argv[1], "-o") == 0) && (strcmp (argv[3], "-i") == 0)) {
        fr = fopen(argv[4],"r");
        fw = fopen(argv[2],"w");
        if(validarRutaArchivo(fr,argv[4])){
        ifd = fileno(fr);
        ofd = fileno(fw);
        buffer_size_read = 1;
        buffer_size_write = 1;
        exe_code = funcionMips(ifd,ofd,buffer_size_read,buffer_size_write);
        fclose(fr);
        fclose(fw);
        }
    }
    else if ((strcmp (argv[3], "-o") == 0) && (strcmp (argv[1], "-i") == 0)) {
        fr = fopen(argv[2],"r");
        fw = fopen(argv[4],"w");
        if(validarRutaArchivo(fr,argv[2])){ 
        ifd = fileno(fr);
        ofd = fileno(fw);
        buffer_size_read = 1;
        buffer_size_write = 1;
        exe_code = funcionMips(ifd,ofd,buffer_size_read,buffer_size_write);
        fclose(fr);
        fclose(fw);
        }
    }
    else if ((strcmp (argv[1], "-i") == 0) && (strcmp (argv[3], "-I") == 0) && (validarBuffer(argv[4]))){
        fr = fopen(argv[2],"r");
        if(validarRutaArchivo(fr,argv[2])){
        fw = stdout;
        ifd = fileno(fr);
        ofd = fileno(fw);
        buffer_size_read = atoi(argv[4]);
        buffer_size_write = 1;
        exe_code = funcionMips(ifd,ofd,buffer_size_read,buffer_size_write);
        fclose(fr);
        }
    }
    else if ((strcmp (argv[1],"-o") == 0) && (strcmp (argv[3],"-O") == 0) && (validarBuffer(argv[4]))){
        fw = fopen(argv[2],"w");    
        fr = stdin;
        ifd = fileno(fr);
        ofd = fileno(fw);
        buffer_size_read = 1;
        buffer_size_write = atoi(argv[4]);
        exe_code = funcionMips(ifd,ofd,buffer_size_read,buffer_size_write);
        fclose(fw);
    }
    else if ((strcmp (argv[1],"-i") == 0) && (strcmp (argv[3],"-O") == 0) && (validarBuffer(argv[4]))){
        fr = fopen(argv[2],"r");
        if(validarRutaArchivo(fr,argv[2])){
        fw = stdout;
        ifd = fileno(fr);
        ofd = fileno(fw);
        buffer_size_read = 1;
        buffer_size_write = atoi(argv[4]);
        exe_code = funcionMips(ifd,ofd,buffer_size_read,buffer_size_write);
        fclose(fr);
        }
    }
    else if ((strcmp (argv[1],"-o") == 0) && (strcmp (argv[3],"-I") == 0) && (validarBuffer(argv[4]))){
        fw = fopen(argv[2],"w");
        fr = stdin;
        ifd = fileno(fr);
        ofd = fileno(fw);
        buffer_size_read = atoi(argv[4]);
        buffer_size_write = 1;
        exe_code = funcionMips(ifd,ofd,buffer_size_read,buffer_size_write);
        fclose(fw);
    }
    else if ((strcmp (argv[1],"-I") == 0) && (strcmp (argv[3],"-O") == 0) && (validarBuffer(argv[2])) && (validarBuffer(argv[4]))){
       fr = stdin;
       fw = stdout;
       ifd = fileno(fr);
       ofd = fileno(fw);
       buffer_size_read = atoi(argv[2]);
       buffer_size_write = atoi(argv[4]);
       exe_code = funcionMips(ifd,ofd,buffer_size_read,buffer_size_write);    
    }
    else{
        printf("Ingreso de comandos incorrectos \n");
    }
    return exe_code;
}

int three_arguments(int argc, char* argv[]){

    int exe_code = 0;

    //File pointers
    FILE* fr;
    FILE* fw;

    //File descriptors
    int ifd;
    int ofd;

    //Buffer sizes
    int buffer_size_read;
    int buffer_size_write;

    if((strcmp(argv[1],"-i") == 0)&&(strcmp(argv[3],"-o") == 0)&&(strcmp(argv[5],"-I") == 0) && (validarBuffer(argv[6]))){
        fr = fopen(argv[2],"r");
        fw = fopen(argv[4],"w");
        if(validarRutaArchivo(fr,argv[2])){
        ifd = fileno(fr);
        ofd = fileno(fw);
        buffer_size_read = atoi(argv[6]);
        buffer_size_write = 1;
        exe_code = funcionMips(ifd,ofd,buffer_size_read,buffer_size_write);
        fclose(fr);
        fclose(fw);
        }
    }
    else if ((strcmp(argv[1],"-i") == 0)&&(strcmp(argv[3],"-o") == 0)&&(strcmp(argv[5],"-O") == 0) && (validarBuffer(argv[6]))){
        fr = fopen(argv[2],"r");
        fw = fopen(argv[4],"w");
        if(validarRutaArchivo(fr,argv[2])){
        ifd = fileno(fr);
        ofd = fileno(fw);
        buffer_size_read = 1;
        buffer_size_write = atoi(argv[6]);
        exe_code = funcionMips(ifd,ofd,buffer_size_read,buffer_size_write);
        fclose(fr);
        fclose(fw);
        }        
    }
    else if ((strcmp(argv[1],"-o") == 0)&&(strcmp(argv[3],"-I") == 0)&&(strcmp(argv[5],"-O") == 0) && (validarBuffer(argv[4])) && (validarBuffer(argv[6]))){
        fr = stdin;
        fw = fopen(argv[2],"w");
        ifd = fileno(fr);
        ofd = fileno(fw);
        buffer_size_read = atoi(argv[4]);
        buffer_size_write = atoi(argv[6]);
        exe_code = funcionMips(ifd,ofd,buffer_size_read,buffer_size_write);
        fclose(fw);
    }
    else if ((strcmp(argv[1],"-i") == 0)&&(strcmp(argv[3],"-I") == 0)&&(strcmp(argv[5],"-O") == 0) && (validarBuffer(argv[4])) && (validarBuffer(argv[6]))){
        fr = fopen(argv[2],"r");
        if(validarRutaArchivo(fr,argv[2])){
        fw = stdout;
        ifd = fileno(fr);
        ofd = fileno(fw);
        buffer_size_read = atoi(argv[4]);
        buffer_size_write = atoi(argv[6]);
        exe_code = funcionMips(ifd,ofd,buffer_size_read,buffer_size_write);
        fclose(fr);
        } 
    }
    return exe_code;
}

int four_arguments(int argc, char* argv[]){
    
    int exe_code;
    //File Pointers
    FILE* fr;
    FILE* fw;

    //File descriptors
    int ifd;   
    int ofd;

    //Buffer sizes
    int buffer_size_read;
    int buffer_size_write;

    if ((strcmp(argv[1],"-i") == 0)&&(strcmp(argv[3],"-o") == 0)&&(strcmp(argv[5],"-I") == 0) && (strcmp(argv[7],"-O") == 0) && (validarBuffer(argv[6]) && (validarBuffer(argv[8])))){
        fr = fopen(argv[2],"r");
        fw = fopen(argv[4],"w");
        if(validarRutaArchivo(fr,argv[2])){
        ifd = fileno(fr);
        ofd = fileno(fw);
        buffer_size_read = atoi(argv[6]);
        buffer_size_write = atoi(argv[8]);
        exe_code = funcionMips(ifd,ofd,buffer_size_read,buffer_size_write);
        fclose(fr);
        fclose(fw);
        } 
    }
    return exe_code;
}

int versionDisplay(){
    printf("TP1 - Version 1.0 FIUBA 2017\n");
    printf("Alumnos:\n");
    printf("Charytoniuk, Martin 96354\n");
    printf("Perez, Martin  97378 \n");
    printf("Reimondo, Matias 95899\n");
    printf("\n");
    return 0;
}

int helpDisplay(){
    printf("Usage:\n"
            "tp0 -h\n"
            "tp0 -V\n"
            "tp0 [options]\n"
            "Options:\n"
            "-V, --version Print version and quit.\n"
            "-h, --help    Print this information.\n"
            "-i, --input   Location of the input file.\n"
            "-o, --output  Location of the output file.\n"
            "Examples:\n"
            "tp0 -i ~/input -o ~/output\n");
    printf("\n");
    return 0;
}

int version_option(int argc, char*argv[]){
    int opt;
    opt = getopt(argc,argv,OPTIONS);
    while(opt != -1){
        switch(opt){
            case 'V':
                versionDisplay();
                break;
            case 'h':
                helpDisplay();
                break;
            default:
                printf("No existe el comando \n");
                break;
        }
        opt = getopt(argc,argv,OPTIONS);
    }
    return 0;
}

